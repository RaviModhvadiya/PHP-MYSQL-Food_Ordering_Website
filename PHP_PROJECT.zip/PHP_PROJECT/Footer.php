<footer id="main-footer" class="site-footer">
  <p>&copy; 2025 Our Food Website. All rights reserved.</p>

  <div id="footer-links" class="footer-links">
    <a href="About.php">About Us</a> |
    <a href="Contact.php">Contact</a> |
    <a href="#">Privacy Policy</a> |
    <a href="#">Terms of Service</a>
  </div>

  <div id="footer-social" class="footer-social">
    <a href="https://facebook.com" target="_blank" class="social facebook" title="Facebook">
      <i class="fab fa-facebook-f"></i>
    </a>
    <a href="https://instagram.com" target="_blank" class="social instagram" title="Instagram">
      <i class="fab fa-instagram"></i>
    </a>
    <a href="https://twitter.com" target="_blank" class="social twitter" title="Twitter">
      <i class="fab fa-twitter"></i>
    </a>
    <a href="https://linkedin.com" target="_blank" class="social linkedin" title="LinkedIn">
      <i class="fab fa-linkedin-in"></i>
    </a>
    <a href="https://pinterest.com" target="_blank" class="social pinterest" title="Pinterest">
      <i class="fab fa-pinterest-p"></i>
    </a>
  </div>
</footer>