<?php
require 'config.php';
require_once 'auth_check.php';
?>
<?php
if (!isset($_SESSION['cart'])) {
  $_SESSION['cart'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Add to cart
  if (isset($_POST['add_to_cart'])) {
    $id = isset($_POST['item_id']) ? trim($_POST['item_id']) : '';
    $name = isset($_POST['item_name']) ? trim($_POST['item_name']) : 'Item';
    $price = isset($_POST['item_price']) ? floatval($_POST['item_price']) : 0.0;

    $found = false;
    foreach ($_SESSION['cart'] as &$ci) {
      if (isset($ci['id']) && $ci['id'] === $id) {
        $ci['quantity'] = isset($ci['quantity']) ? intval($ci['quantity']) + 1 : 1;
        $found = true;
        break;
      }
    }
    unset($ci);

    if (!$found) {
      $_SESSION['cart'][] = [
        'id' => $id,
        'name' => $name,
        'price' => $price,
        'quantity' => 1
      ];
    }

    header("Location: Cart.php");
    exit();
  }

  // Update quantity
  if (isset($_POST['update_quantity'])) {
    $index = isset($_POST['item_index']) ? intval($_POST['item_index']) : -1;
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;

    if ($index >= 0 && isset($_SESSION['cart'][$index])) {
      if ($quantity > 0) {
        $_SESSION['cart'][$index]['quantity'] = $quantity;
      } else {
        unset($_SESSION['cart'][$index]);
        $_SESSION['cart'] = array_values($_SESSION['cart']);
      }
    }

    header("Location: Cart.php");
    exit();
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your Cart</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      background: #111;
      color: #fff;
    }

    main {
      max-width: 1100px;
      margin: 2rem auto;
      padding: 0 1.5rem;
      min-height: calc(100vh - 300px);
    }

    h1 {
      text-align: center;
      color: #ffb703;
      margin-bottom: 2rem;
      font-size: 2.5rem;
    }

    .empty-cart {
      text-align: center;
      padding: 4rem 1rem;
    }

    .empty-cart p {
      color: #ccc;
      font-size: 1.2rem;
      margin-bottom: 1.5rem;
    }

    .empty-cart a {
      display: inline-block;
      background: #e63946;
      color: #fff;
      padding: 0.9rem 2rem;
      border-radius: 8px;
      text-decoration: none;
      font-weight: bold;
      transition: all 0.3s ease;
    }

    .empty-cart a:hover {
      background: #ffb703;
      color: #111;
      transform: translateY(-2px);
    }

    .cart-items {
      margin-bottom: 2rem;
    }

    .cart-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: #1c1c1c;
      padding: 1.5rem;
      margin-bottom: 1.2rem;
      border-radius: 12px;
      border: 2px solid #2a2a2a;
      transition: all 0.3s ease;
    }

    .cart-item:hover {
      border-color: #ffb703;
      box-shadow: 0 4px 15px rgba(255, 183, 3, 0.15);
    }

    .item-info {
      flex: 1;
    }

    .item-info h3 {
      margin: 0 0 0.5rem 0;
      font-size: 1.3rem;
      color: #ffb703;
    }

    .item-info p {
      margin: 0;
      color: #4ade80;
      font-size: 1.1rem;
      font-weight: bold;
    }

    .quantity-control {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .quantity-control button {
      background: #e63946;
      border: none;
      color: #fff;
      font-size: 1.2rem;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      cursor: pointer;
      transition: all 0.3s ease;
      font-weight: bold;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .quantity-control button:hover {
      background: #c82333;
      transform: scale(1.1);
    }

    .quantity-control span {
      min-width: 35px;
      text-align: center;
      font-weight: bold;
      font-size: 1.2rem;
    }

    .cart-summary {
      background: #1c1c1c;
      padding: 2rem;
      border-radius: 12px;
      margin-top: 2rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border: 2px solid #333;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
    }

    .cart-summary span {
      font-size: 1.5rem;
      font-weight: bold;
      color: #ffb703;
    }

    .checkout-btn {
      background: #e63946;
      color: #fff;
      border: none;
      padding: 1rem 2.5rem;
      border-radius: 8px;
      font-size: 1.1rem;
      font-weight: bold;
      cursor: pointer;
      transition: all 0.3s ease;
      text-decoration: none;
      display: inline-block;
    }

    .checkout-btn:hover {
      background: #c82333;
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
    }

    .checkout-btn[disabled] {
      background: #555;
      cursor: not-allowed;
      opacity: 0.6;
    }

    @media (max-width: 768px) {
      .cart-item {
        flex-direction: column;
        align-items: flex-start;
        gap: 1rem;
      }

      .quantity-control {
        width: 100%;
        justify-content: center;
      }

      .cart-summary {
        flex-direction: column;
        gap: 1.5rem;
        text-align: center;
      }

      .checkout-btn {
        width: 100%;
      }
    }
  </style>
</head>

<body>

  <?php include 'Header.php'; ?>

  <main>
    <h1>Your Cart</h1>

    <?php
    $total = 0;
    if (empty($_SESSION['cart'])):
    ?>
      <div class="empty-cart">
        <p>Your cart is empty.</p>
        <a href="Category.php">Browse Menu</a>
      </div>
    <?php
    else:
    ?>
      <div class="cart-items">
        <?php
        foreach ($_SESSION['cart'] as $index => $item):
          $total += $item['price'] * $item['quantity'];
        ?>
          <div class="cart-item">
            <div class="item-info">
              <h3><?= htmlspecialchars($item['name']) ?></h3>
              <p>₹<?= number_format($item['price'], 2) ?></p>
            </div>
            <div class="quantity-control">
              <form method="POST" style="display:inline">
                <input type="hidden" name="item_index" value="<?= $index ?>">
                <input type="hidden" name="quantity" value="<?= max(0, $item['quantity'] - 1) ?>">
                <button type="submit" name="update_quantity">−</button>
              </form>
              <span><?= intval($item['quantity']) ?></span>
              <form method="POST" style="display:inline">
                <input type="hidden" name="item_index" value="<?= $index ?>">
                <input type="hidden" name="quantity" value="<?= $item['quantity'] + 1 ?>">
                <button type="submit" name="update_quantity">+</button>
              </form>
            </div>
          </div>
        <?php
        endforeach;
        ?>
      </div>

      <div class="cart-summary">
        <span>Total: ₹<?= number_format($total, 2) ?></span>
        <a href="Checkout.php" class="checkout-btn">Proceed to Checkout</a>
      </div>
    <?php
    endif;
    ?>
  </main>

  <?php include 'Footer.php'; ?>

</body>

</html>