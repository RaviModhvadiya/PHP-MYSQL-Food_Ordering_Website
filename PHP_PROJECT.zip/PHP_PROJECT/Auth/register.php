<?php
session_start();
if (isset($_SESSION['user_id'])) {
  header("Location: ../Home.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register</title>
  <link rel="stylesheet" href="../style.css">
  <style>
    body {
      background: #111;
      color: #fff;
    }

    .auth-wrapper {
      min-height: calc(100vh - 200px);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    }

    .auth-card {
      background: #1c1c1c;
      padding: 2.5rem;
      border-radius: 12px;
      width: 100%;
      max-width: 480px;
      color: #fff;
      border: 2px solid #2a2a2a;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
    }

    .auth-card h2 {
      color: #ffb703;
      text-align: center;
      margin-bottom: 2rem;
      font-size: 2rem;
    }

    .auth-card input {
      width: 100%;
      padding: 0.9rem;
      margin: 0.8rem 0;
      border-radius: 8px;
      border: 2px solid #333;
      background: #252525;
      color: #fff;
      font-size: 1rem;
      transition: all 0.3s ease;
    }

    .auth-card input:focus {
      outline: none;
      border-color: #ffb703;
      background: #2a2a2a;
    }

    .auth-card button {
      width: 100%;
      padding: 1rem;
      background: #e63946;
      border: none;
      color: #fff;
      border-radius: 8px;
      cursor: pointer;
      font-weight: bold;
      font-size: 1.1rem;
      margin-top: 1rem;
      transition: all 0.3s ease;
    }

    .auth-card button:hover {
      background: #c82333;
      transform: translateY(-2px);
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
    }

    .msg {
      padding: 0.9rem;
      margin-bottom: 1rem;
      border-radius: 8px;
      font-size: 0.95rem;
    }

    .error {
      background: #4f1b1b;
      color: #ffdede;
      border: 1px solid #e63946;
    }

    .success {
      background: #1b4f2b;
      color: #dfffe6;
      border: 1px solid #22c55e;
    }

    .small-link {
      margin-top: 1.5rem;
      display: block;
      text-align: center;
      color: #ffb703;
      text-decoration: none;
      transition: all 0.3s ease;
    }

    .small-link:hover {
      color: #e63946;
    }

    .field-error {
      color: #e63946;
      font-size: 0.9rem;
      margin-top: 0.3rem;
      margin-bottom: 0.5rem;
      display: none;
    }

    .field-error.visible {
      display: block;
    }

    @media (max-width: 480px) {
      .auth-card {
        padding: 2rem;
      }

      .auth-card h2 {
        font-size: 1.7rem;
      }
    }
  </style>
</head>

<body>
  <?php include_once __DIR__ . '/../Header.php'; ?>

  <main class="auth-wrapper">
    <div class="auth-card">
      <h2>Register</h2>

      <?php
      if (isset($_SESSION['error'])) {
        echo "<div class='msg error'>" . htmlspecialchars($_SESSION['error']) . "</div>";
        unset($_SESSION['error']);
      }
      if (isset($_SESSION['success'])) {
        echo "<div class='msg success'>" . htmlspecialchars($_SESSION['success']) . "</div>";
        unset($_SESSION['success']);
      }
      ?>

      <form id="registerForm" action="registerprocess.php" method="POST" novalidate>
        <input id="name" type="text" name="name" placeholder="Full Name" required>
        <div class="field-error" id="error-name">Please enter your name.</div>

        <input id="email" type="email" name="email" placeholder="Email Address" required>
        <div class="field-error" id="error-email">Please enter your email.</div>

        <input id="password" type="password" name="password" placeholder="Password" required>
        <div class="field-error" id="error-password">Please enter a password.</div>

        <input id="confirm_password" type="password" name="confirm_password" placeholder="Confirm Password" required>
        <div class="field-error" id="error-confirm">Please confirm your password.</div>

        <button type="submit">Register</button>
      </form>

      <a class="small-link" href="login.php">Already have an account? Login</a>
    </div>
  </main>

  <?php include_once __DIR__ . '/../Footer.php'; ?>

  <script>
    (function() {
      const form = document.getElementById('registerForm');
      const fields = {
        name: document.getElementById('name'),
        email: document.getElementById('email'),
        password: document.getElementById('password'),
        confirm: document.getElementById('confirm_password')
      };
      const errors = {
        name: document.getElementById('error-name'),
        email: document.getElementById('error-email'),
        password: document.getElementById('error-password'),
        confirm: document.getElementById('error-confirm')
      };

      function clearError(el) {
        el.classList.remove('visible');
        el.textContent = '';
      }

      function showError(el, msg) {
        el.textContent = msg;
        el.classList.add('visible');
      }

      Object.keys(fields).forEach(k => {
        fields[k].addEventListener('input', () => clearError(errors[k]));
      });

      form.addEventListener('submit', function(e) {
        let hasError = false;

        Object.values(errors).forEach(clearError);

        if (!fields.name.value.trim()) {
          showError(errors.name, 'Please enter your name.');
          hasError = true;
        }
        if (!fields.email.value.trim()) {
          showError(errors.email, 'Please enter your email.');
          hasError = true;
        }
        if (!fields.password.value) {
          showError(errors.password, 'Please enter a password.');
          hasError = true;
        }
        if (!fields.confirm.value) {
          showError(errors.confirm, 'Please confirm your password.');
          hasError = true;
        }

        if (!hasError && fields.password.value !== fields.confirm.value) {
          showError(errors.confirm, 'Passwords do not match.');
          hasError = true;
        }

        if (hasError) {
          e.preventDefault();
          const first = form.querySelector('.field-error.visible');
          if (first) {
            const id = first.id.replace('error-', '');
            const fld = document.getElementById(id);
            if (fld) fld.focus();
          }
        }
      });
    })();
  </script>
</body>

</html>