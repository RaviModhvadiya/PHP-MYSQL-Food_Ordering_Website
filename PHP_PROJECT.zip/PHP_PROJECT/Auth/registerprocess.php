<?php
session_start();
require_once '../config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $name = mysqli_real_escape_string($conn, $_POST['name'] ?? '');
  $email = mysqli_real_escape_string($conn, $_POST['email'] ?? '');
  $password = $_POST['password'] ?? '';
  $confirm_password = $_POST['confirm_password'] ?? '';

  $genericError = "Please fill all fields correctly";

  if ($name === '' || $email === '' || $password === '' || $confirm_password === '') {
    if ($name === '') {
      $_SESSION['error'] = "Please enter your name";
    } elseif ($email === '') {
      $_SESSION['error'] = "Please enter your email";
    } elseif ($password === '') {
      $_SESSION['error'] = "Please enter your password";
    } else { // confirm_password empty
      $_SESSION['error'] = "Please confirm your password";
    }
    header("Location: register.php");
    exit();
  }

  if ($password !== $confirm_password) {
    $_SESSION['error'] = "Passwords do not match";
    header("Location: register.php");
    exit();
  }

  // Check if email already exists
  $check_query = "SELECT * FROM users WHERE email = '$email'";
  $result = mysqli_query($conn, $check_query);
  if (mysqli_num_rows($result) > 0) {
    $_SESSION['error'] = "Email already exists";
    header("Location: register.php");
    exit();
  }

  $hashed_password = password_hash($password, PASSWORD_DEFAULT);
  $query = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$hashed_password')";

  if (mysqli_query($conn, $query)) {
    $_SESSION['success'] = "Registration successful. Please login.";
    header("Location: login.php");
  } else {
    $_SESSION['error'] = "Registration failed";
    header("Location: register.php");
  }
  exit();
}
