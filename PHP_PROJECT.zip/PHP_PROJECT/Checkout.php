<?php
require 'config.php';
require_once 'auth_check.php';

if (empty($_SESSION['cart'])) {
  header("Location: Cart.php");
  exit();
}

$total = 0;
foreach ($_SESSION['cart'] as $item) {
  $total += $item['price'] * $item['quantity'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['payment_method'], $_POST['phone'], $_POST['address'])) {

    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;
    $user_name = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'Guest';

    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $payment_method = mysqli_real_escape_string($conn, $_POST['payment_method']);
    $total_amount = $total;

    // Create the Item List String
    $item_list = [];
    foreach ($_SESSION['cart'] as $cart_item) {
      $item_list[] = $cart_item['name'] . " (" . $cart_item['quantity'] . ")";
    }
    $order_items_string = mysqli_real_escape_string($conn, implode(", ", $item_list));

    // Insert into the SINGLE 'orders' table
    $query = "INSERT INTO orders (user_id, user_name, phone, address, total_amount, payment_method, order_items) 
              VALUES ('$user_id', '$user_name', '$phone', '$address', '$total_amount', '$payment_method', '$order_items_string')";

    if (mysqli_query($conn, $query)) {
      // Success
      $_SESSION['cart'] = []; // Clear cart
      $_SESSION['checkout_success'] = true;
      header("Location: OrderSuccess.php");
      exit();
    } else {
      echo "Error: " . mysqli_error($conn); // For debugging
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Checkout</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      background: #111;
      color: #fff;
    }

    main {
      max-width: 1000px;
      margin: 0 auto;
      padding: 2rem 1.5rem;
      min-height: calc(100vh - 300px);
    }

    h1 {
      text-align: center;
      color: #ffb703;
      margin-bottom: 2.5rem;
      font-size: 2.5rem;
    }

    .checkout-form {
      max-width: 650px;
      margin: 0 auto;
      padding: 2.5rem;
      background: #1c1c1c;
      border-radius: 12px;
      border: 2px solid #2a2a2a;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
    }

    .order-summary {
      margin-bottom: 2rem;
      padding: 1.5rem;
      background: #252525;
      border-radius: 10px;
      border: 1px solid #333;
    }

    .order-summary h3 {
      color: #ffb703;
      margin-bottom: 1.5rem;
      font-size: 1.5rem;
    }

    .order-item {
      display: flex;
      justify-content: space-between;
      margin-bottom: 0.8rem;
      padding-bottom: 0.8rem;
      border-bottom: 1px solid #333;
      color: #ddd;
    }

    .order-item:last-child {
      border-bottom: none;
    }

    .order-total {
      display: flex;
      justify-content: space-between;
      font-weight: bold;
      font-size: 1.2rem;
      margin-top: 1rem;
      padding-top: 1rem;
      border-top: 2px solid #ffb703;
      color: #ffb703;
    }

    .form-group {
      margin-bottom: 1.5rem;
    }

    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      color: #ffb703;
      font-weight: bold;
      font-size: 1.1rem;
    }

    .form-group input,
    .form-group select,
    .form-group textarea {
      width: 100%;
      padding: 1rem;
      border-radius: 8px;
      background: #252525;
      border: 2px solid #333;
      color: #fff;
      font-size: 1rem;
      transition: all 0.3s ease;
    }

    .form-group textarea {
      resize: vertical;
      min-height: 80px;
    }

    .form-group input:focus,
    .form-group select:focus,
    .form-group textarea:focus {
      outline: none;
      border-color: #ffb703;
    }

    .checkout-btn {
      width: 100%;
      padding: 1.2rem;
      background: #e63946;
      color: #fff;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-size: 1.2rem;
      font-weight: bold;
      transition: all 0.3s ease;
      margin-top: 1rem;
    }

    .checkout-btn:hover {
      background: #c82333;
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
    }
  </style>
</head>

<body>
  <?php include 'Header.php'; ?>

  <main>
    <h1>Checkout</h1>

    <div class="checkout-form">
      <div class="order-summary">
        <h3>Order Summary</h3>
        <?php foreach ($_SESSION['cart'] as $item): ?>
          <div class="order-item">
            <span><?= htmlspecialchars($item['name']) ?> × <?= $item['quantity'] ?></span>
            <span>₹<?= number_format($item['price'] * $item['quantity'], 2) ?></span>
          </div>
        <?php endforeach; ?>
        <div class="order-total">
          <span>Total:</span>
          <span>₹<?= number_format($total, 2) ?></span>
        </div>
      </div>

      <form method="POST">
        <div class="form-group">
          <label for="phone">Phone Number</label>
          <input type="tel" id="phone" name="phone" placeholder="Enter your phone number" required pattern="[0-9]{10}" title="10 digit phone number">
        </div>

        <div class="form-group">
          <label for="address">Delivery Address</label>
          <textarea id="address" name="address" placeholder="Enter your full delivery address" required></textarea>
        </div>

        <div class="form-group">
          <label for="payment_method">Select Payment Method</label>
          <select name="payment_method" id="payment_method" required>
            <option value="">Choose payment method</option>
            <option value="cod">Cash on Delivery</option>
            <option value="upi">UPI</option>
            <option value="card">Credit/Debit Card</option>
          </select>
        </div>

        <button type="submit" class="checkout-btn">Place Order</button>
      </form>
    </div>
  </main>

  <?php include 'Footer.php'; ?>
</body>

</html>