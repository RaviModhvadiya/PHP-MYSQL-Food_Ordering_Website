<?php
require_once 'auth_check.php';

if (!isset($_SESSION['cart'])) {
  $_SESSION['cart'] = [];
}

$cart_message = '';

// Handle Add to Cart (AJAX or normal)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
  $id = isset($_POST['item_id']) ? trim($_POST['item_id']) : '';
  $name = isset($_POST['item_name']) ? trim($_POST['item_name']) : 'Item';
  $price = isset($_POST['item_price']) ? floatval($_POST['item_price']) : 0.0;

  $found = false;
  foreach ($_SESSION['cart'] as &$ci) {
    if (isset($ci['id']) && $ci['id'] === $id) {
      $ci['quantity'] = isset($ci['quantity']) ? intval($ci['quantity']) + 1 : 1;
      $found = true;
      break;
    }
  }
  unset($ci);

  if (!$found) {
    $_SESSION['cart'][] = [
      'id' => $id,
      'name' => $name,
      'price' => $price,
      'quantity' => 1
    ];
  }

  // If Order Now, redirect to cart
  if (isset($_POST['order_now'])) {
    header("Location: Cart.php");
    exit();
  }

  // For Add to Cart, set message
  $cart_message = $name . ' added to cart!';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Our Menu - Categories</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .search-container {
      max-width: 600px;
      margin: 2rem auto;
      padding: 0 1rem;
    }

    .search-box {
      position: relative;
      width: 100%;
    }

    .search-box input {
      width: 100%;
      padding: 1rem 3rem 1rem 1.2rem;
      font-size: 1.1rem;
      border: 2px solid #333;
      border-radius: 12px;
      background: #1c1c1c;
      color: #fff;
      transition: all 0.3s ease;
    }

    .search-box input:focus {
      outline: none;
      border-color: #ffb703;
      background: #252525;
    }

    .search-box input::placeholder {
      color: #888;
    }

    .search-box i {
      position: absolute;
      right: 1.2rem;
      top: 50%;
      transform: translateY(-50%);
      color: #ffb703;
      font-size: 1.2rem;
    }

    .no-results {
      text-align: center;
      padding: 3rem 2rem;
      color: #ccc;
      font-size: 1.2rem;
      display: none;
    }

    .no-results.visible {
      display: block;
    }

    .search-stats {
      text-align: center;
      color: #ffb703;
      margin: 1rem 0;
      font-size: 1rem;
      display: none;
    }

    .search-stats.visible {
      display: block;
    }

    /* Toast Notification */
    .toast {
      position: fixed;
      bottom: 30px;
      left: 50%;
      transform: translateX(-50%) translateY(100px);
      background: #1c1c1c;
      color: #fff;
      padding: 1rem 2rem;
      border-radius: 8px;
      border: 2px solid #4ade80;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
      z-index: 9999;
      display: flex;
      align-items: center;
      gap: 10px;
      opacity: 0;
      transition: all 0.3s ease;
    }

    .toast.show {
      opacity: 1;
      transform: translateX(-50%) translateY(0);
    }

    .toast i {
      color: #4ade80;
      font-size: 1.2rem;
    }

    .toast span {
      font-weight: 500;
    }

    .toast .view-cart {
      background: #4ade80;
      color: #111;
      padding: 0.4rem 1rem;
      border-radius: 5px;
      text-decoration: none;
      font-weight: bold;
      margin-left: 10px;
      font-size: 0.9rem;
    }

    .toast .view-cart:hover {
      background: #22c55e;
    }
  </style>
</head>

<body>

  <?php include 'Header.php'; ?>

  <!-- Toast Notification -->
  <div class="toast" id="cartToast">
    <i class="fas fa-check-circle"></i>
    <span id="toastMessage">Item added to cart!</span>
    <a href="Cart.php" class="view-cart">View Cart</a>
  </div>

  <section class="category-section">
    <h1 class="section-title">Choose Your Favorite Food</h1>

    <div class="search-container">
      <div class="search-box">
        <input type="text" id="searchInput" placeholder="Search for dishes...">
        <i class="fas fa-search"></i>
      </div>
      <div class="search-stats" id="searchStats"></div>
    </div>

    <div class="no-results" id="noResults">
      <i class="fas fa-search" style="font-size: 3rem; color: #666; margin-bottom: 1rem;"></i>
      <p>No dishes found matching your search.</p>
    </div>

    <!-- Gujarati Menu -->
    <div class="tab-content" data-category="gujarati">
      <h2 class="menu-title">Gujarati Menu</h2>
      <div class="food-items">
        <?php
        $gujarati_items = [
          ['id' => 'dhokla', 'name' => 'Dhokla', 'price' => 80, 'image' => 'Images/Dhokla.jpg'],
          ['id' => 'thepla', 'name' => 'Thepla', 'price' => 60, 'image' => 'Images/Thepla.jpg'],
          ['id' => 'khandvi', 'name' => 'Khandvi', 'price' => 90, 'image' => 'Images/khandvi.jpg'],
          ['id' => 'fafda', 'name' => 'Fafda', 'price' => 70, 'image' => 'Images/fafda.jpg'],
        ];
        foreach ($gujarati_items as $item): ?>
          <div class="food-card" data-name="<?= $item['name'] ?>" data-price="<?= $item['price'] ?>">
            <img src="<?= $item['image'] ?>" alt="<?= $item['name'] ?>">
            <h3><?= $item['name'] ?></h3>
            <span class="price">₹<?= $item['price'] ?></span>
            <form method="POST" class="card-form">
              <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
              <input type="hidden" name="item_name" value="<?= $item['name'] ?>">
              <input type="hidden" name="item_price" value="<?= $item['price'] ?>">
              <button class="btn btn-order" type="submit" name="add_to_cart" value="1" onclick="this.form.elements['order_now'].value='1'">Order Now</button>
              <input type="hidden" name="order_now" value="">
              <button class="btn btn-cart" type="button" onclick="addToCart(this.form, '<?= htmlspecialchars($item['name']) ?>')">Add to Cart</button>
            </form>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Punjabi Menu -->
    <div class="tab-content" data-category="punjabi">
      <h2 class="menu-title">Punjabi Menu</h2>
      <div class="food-items">
        <?php
        $punjabi_items = [
          ['id' => 'chole', 'name' => 'Chole', 'price' => 120, 'image' => 'Images/Chole.jpg'],
          ['id' => 'butter_paneer', 'name' => 'Butter Paneer', 'price' => 150, 'image' => 'Images/butter-paneer.jpg'],
          ['id' => 'rajma', 'name' => 'Rajma Masala', 'price' => 130, 'image' => 'Images/rajma.jpg'],
          ['id' => 'dal_makhani', 'name' => 'Dal Makhani', 'price' => 140, 'image' => 'Images/dal-makhani.jpg'],
        ];
        foreach ($punjabi_items as $item): ?>
          <div class="food-card" data-name="<?= $item['name'] ?>" data-price="<?= $item['price'] ?>">
            <img src="<?= $item['image'] ?>" alt="<?= $item['name'] ?>">
            <h3><?= $item['name'] ?></h3>
            <span class="price">₹<?= $item['price'] ?></span>
            <form method="POST" class="card-form">
              <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
              <input type="hidden" name="item_name" value="<?= $item['name'] ?>">
              <input type="hidden" name="item_price" value="<?= $item['price'] ?>">
              <button class="btn btn-order" type="submit" name="add_to_cart" value="1" onclick="this.form.elements['order_now'].value='1'">Order Now</button>
              <input type="hidden" name="order_now" value="">
              <button class="btn btn-cart" type="button" onclick="addToCart(this.form, '<?= htmlspecialchars($item['name']) ?>')">Add to Cart</button>
            </form>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Chinese Menu -->
    <div class="tab-content" data-category="chinese">
      <h2 class="menu-title">Chinese Menu</h2>
      <div class="food-items">
        <?php
        $chinese_items = [
          ['id' => 'spring_rolls', 'name' => 'Spring Rolls', 'price' => 100, 'image' => 'Images/Springroll.jpg'],
          ['id' => 'chowmein', 'name' => 'Chowmein', 'price' => 90, 'image' => 'Images/Chowmein.jpg'],
          ['id' => 'manchurian', 'name' => 'Veg Manchurian', 'price' => 110, 'image' => 'Images/manchurian.jpg'],
          ['id' => 'fried_rice', 'name' => 'Fried Rice', 'price' => 95, 'image' => 'Images/fried-rice.jpg'],
        ];
        foreach ($chinese_items as $item): ?>
          <div class="food-card" data-name="<?= $item['name'] ?>" data-price="<?= $item['price'] ?>">
            <img src="<?= $item['image'] ?>" alt="<?= $item['name'] ?>">
            <h3><?= $item['name'] ?></h3>
            <span class="price">₹<?= $item['price'] ?></span>
            <form method="POST" class="card-form">
              <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
              <input type="hidden" name="item_name" value="<?= $item['name'] ?>">
              <input type="hidden" name="item_price" value="<?= $item['price'] ?>">
              <button class="btn btn-order" type="submit" name="add_to_cart" value="1" onclick="this.form.elements['order_now'].value='1'">Order Now</button>
              <input type="hidden" name="order_now" value="">
              <button class="btn btn-cart" type="button" onclick="addToCart(this.form, '<?= htmlspecialchars($item['name']) ?>')">Add to Cart</button>
            </form>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Pizza Menu -->
    <div class="tab-content" data-category="pizza">
      <h2 class="menu-title">Pizza Menu</h2>
      <div class="food-items">
        <?php
        $pizza_items = [
          ['id' => 'margherita', 'name' => 'Margherita', 'price' => 200, 'image' => 'Images/Pizza.jpg'],
          ['id' => 'farmhouse', 'name' => 'Farmhouse', 'price' => 250, 'image' => 'Images/Pizza2.jpg'],
          ['id' => 'pepperoni', 'name' => 'Pepperoni', 'price' => 280, 'image' => 'Images/pepperoni.jpg'],
          ['id' => 'veggie_supreme', 'name' => 'Veggie Supreme', 'price' => 260, 'image' => 'Images/veggie-supreme.jpg'],
        ];
        foreach ($pizza_items as $item): ?>
          <div class="food-card" data-name="<?= $item['name'] ?>" data-price="<?= $item['price'] ?>">
            <img src="<?= $item['image'] ?>" alt="<?= $item['name'] ?>">
            <h3><?= $item['name'] ?></h3>
            <span class="price">₹<?= $item['price'] ?></span>
            <form method="POST" class="card-form">
              <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
              <input type="hidden" name="item_name" value="<?= $item['name'] ?>">
              <input type="hidden" name="item_price" value="<?= $item['price'] ?>">
              <button class="btn btn-order" type="submit" name="add_to_cart" value="1" onclick="this.form.elements['order_now'].value='1'">Order Now</button>
              <input type="hidden" name="order_now" value="">
              <button class="btn btn-cart" type="button" onclick="addToCart(this.form, '<?= htmlspecialchars($item['name']) ?>')">Add to Cart</button>
            </form>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Cold Drinks -->
    <div class="tab-content" data-category="drinks">
      <h2 class="menu-title">Cold Drinks</h2>
      <div class="food-items">
        <?php
        $drinks_items = [
          ['id' => 'coca_cola', 'name' => 'Coca Cola', 'price' => 40, 'image' => 'Images/coca-cola.jpg'],
          ['id' => 'pepsi', 'name' => 'Pepsi', 'price' => 40, 'image' => 'Images/Pepsi.jpg'],
          ['id' => 'sprite', 'name' => 'Sprite', 'price' => 40, 'image' => 'Images/sprite.jpg'],
          ['id' => 'fanta', 'name' => 'Fanta', 'price' => 40, 'image' => 'Images/fanta.jpg'],
        ];
        foreach ($drinks_items as $item): ?>
          <div class="food-card" data-name="<?= $item['name'] ?>" data-price="<?= $item['price'] ?>">
            <img src="<?= $item['image'] ?>" alt="<?= $item['name'] ?>">
            <h3><?= $item['name'] ?></h3>
            <span class="price">₹<?= $item['price'] ?></span>
            <form method="POST" class="card-form">
              <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
              <input type="hidden" name="item_name" value="<?= $item['name'] ?>">
              <input type="hidden" name="item_price" value="<?= $item['price'] ?>">
              <button class="btn btn-order" type="submit" name="add_to_cart" value="1" onclick="this.form.elements['order_now'].value='1'">Order Now</button>
              <input type="hidden" name="order_now" value="">
              <button class="btn btn-cart" type="button" onclick="addToCart(this.form, '<?= htmlspecialchars($item['name']) ?>')">Add to Cart</button>
            </form>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Desserts -->
    <div class="tab-content" data-category="desserts">
      <h2 class="menu-title">Desserts</h2>
      <div class="food-items">
        <?php
        $dessert_items = [
          ['id' => 'choco_cake', 'name' => 'Chocolate Cake', 'price' => 180, 'image' => 'Images/choco-cake.jpg'],
          ['id' => 'ice_cream', 'name' => 'Ice Cream', 'price' => 80, 'image' => 'Images/ice-cream.jpg'],
          ['id' => 'gulab_jamun', 'name' => 'Gulab Jamun', 'price' => 60, 'image' => 'Images/gulab-jamun.jpg'],
          ['id' => 'jalebi', 'name' => 'Jalebi', 'price' => 50, 'image' => 'Images/jalebi.jpg'],
        ];
        foreach ($dessert_items as $item): ?>
          <div class="food-card" data-name="<?= $item['name'] ?>" data-price="<?= $item['price'] ?>">
            <img src="<?= $item['image'] ?>" alt="<?= $item['name'] ?>">
            <h3><?= $item['name'] ?></h3>
            <span class="price">₹<?= $item['price'] ?></span>
            <form method="POST" class="card-form">
              <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
              <input type="hidden" name="item_name" value="<?= $item['name'] ?>">
              <input type="hidden" name="item_price" value="<?= $item['price'] ?>">
              <button class="btn btn-order" type="submit" name="add_to_cart" value="1" onclick="this.form.elements['order_now'].value='1'">Order Now</button>
              <input type="hidden" name="order_now" value="">
              <button class="btn btn-cart" type="button" onclick="addToCart(this.form, '<?= htmlspecialchars($item['name']) ?>')">Add to Cart</button>
            </form>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

  </section>

  <?php include 'Footer.php'; ?>

  <script>
    // Toast notification
    function showToast(message) {
      const toast = document.getElementById('cartToast');
      const toastMsg = document.getElementById('toastMessage');
      toastMsg.textContent = message;
      toast.classList.add('show');
      setTimeout(() => {
        toast.classList.remove('show');
      }, 3000);
    }

    // Add to cart 
    function addToCart(form, itemName) {
      const formData = new FormData(form);
      formData.append('add_to_cart', '1');

      fetch('<?= $_SERVER['PHP_SELF'] ?>', {
          method: 'POST',
          body: formData
        })
        .then(response => {
          showToast(itemName + ' added to cart!');
        })
        .catch(error => {
          console.error('Error:', error);
          showToast('Error adding item to cart');
        });
    }

    // Show item if item was added via form submit

    <?php if ($cart_message): ?>
      document.addEventListener('DOMContentLoaded', function() {
        showToast('<?= addslashes($cart_message) ?>');
      });
    <?php endif; ?>

      // Search Functionality

      (function() {
        const searchInput = document.getElementById('searchInput');
        const foodCards = document.querySelectorAll('.food-card');
        const categories = document.querySelectorAll('.tab-content');
        const noResults = document.getElementById('noResults');
        const searchStats = document.getElementById('searchStats');

        searchInput.addEventListener('input', function() {
          const query = this.value.toLowerCase().trim();
          let visibleCount = 0;

          if (query === '') {
            foodCards.forEach(card => card.style.display = 'block');
            categories.forEach(cat => cat.style.display = 'block');
            noResults.classList.remove('visible');
            searchStats.classList.remove('visible');
            return;
          }

          foodCards.forEach(card => {
            const itemName = card.getAttribute('data-name').toLowerCase();
            const category = card.closest('.tab-content').getAttribute('data-category');
            if (itemName.includes(query) || category.includes(query)) {
              card.style.display = 'block';
              visibleCount++;
            } else {
              card.style.display = 'none';
            }
          });

          categories.forEach(cat => {
            const actualVisible = Array.from(cat.querySelectorAll('.food-card')).filter(card => card.style.display !== 'none');
            cat.style.display = actualVisible.length === 0 ? 'none' : 'block';
          });

          if (visibleCount === 0) {
            noResults.classList.add('visible');
            searchStats.classList.remove('visible');
          } else {
            noResults.classList.remove('visible');
            searchStats.classList.add('visible');
            searchStats.textContent = `Found ${visibleCount} dish${visibleCount !== 1 ? 'es' : ''} matching "${query}"`;
          }
        });
      })();
  </script>
</body>

</html>