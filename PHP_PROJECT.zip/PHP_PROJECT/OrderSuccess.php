<?php
require_once 'auth_check.php';

// Check if order was actually placed
if (!isset($_SESSION['checkout_success'])) {
  header("Location: Cart.php");
  exit();
}
unset($_SESSION['checkout_success']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Success</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      background: #111;
      color: #fff;
    }

    .success-container {
      min-height: calc(100vh - 200px);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    }

    .success-card {
      max-width: 550px;
      width: 100%;
      padding: 3rem;
      background: #1c1c1c;
      border-radius: 12px;
      text-align: center;
      border: 2px solid #2a2a2a;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
    }

    .success-icon {
      font-size: 5rem;
      color: #22c55e;
      margin-bottom: 1.5rem;
      animation: scaleIn 0.5s ease;
    }

    @keyframes scaleIn {
      from {
        transform: scale(0);
        opacity: 0;
      }

      to {
        transform: scale(1);
        opacity: 1;
      }
    }

    .success-card h1 {
      color: #ffb703;
      margin-bottom: 1rem;
      font-size: 2.2rem;
    }

    .success-card p {
      margin: 1.5rem 0;
      color: #ddd;
      font-size: 1.1rem;
      line-height: 1.7;
    }

    .home-btn {
      display: inline-block;
      padding: 1rem 2.5rem;
      background: #e63946;
      color: #fff;
      text-decoration: none;
      border-radius: 8px;
      margin-top: 1.5rem;
      font-weight: bold;
      font-size: 1.1rem;
      transition: all 0.3s ease;
    }

    .home-btn:hover {
      background: #c82333;
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
    }

    @media (max-width: 480px) {
      .success-card {
        padding: 2rem;
      }

      .success-icon {
        font-size: 4rem;
      }

      .success-card h1 {
        font-size: 1.8rem;
      }
    }
  </style>
</head>

<body>
  <?php include 'Header.php'; ?>

  <div class="success-container">
    <div class="success-card">
      <div class="success-icon">✅</div>
      <h1>Order Successful!</h1>
      <p>Thank you for your order. Your delicious food will be delivered to you soon.</p>
      <a href="Home.php" class="home-btn">Return to Home</a>
    </div>
  </div>

  <?php include 'Footer.php'; ?>
</body>

</html>