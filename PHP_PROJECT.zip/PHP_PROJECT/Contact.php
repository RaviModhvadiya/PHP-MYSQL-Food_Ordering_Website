<?php
require 'config.php';
require_once 'auth_check.php';

$message_sent = false;
$error_msg = '';

// Handle Form Submission
if (isset($_POST['send_message'])) {
  $name = mysqli_real_escape_string($conn, trim($_POST['name']));
  $email = mysqli_real_escape_string($conn, trim($_POST['email']));
  $message = mysqli_real_escape_string($conn, trim($_POST['message']));

  if (empty($name) || empty($email) || empty($message)) {
    $error_msg = "Please fill in all fields.";
  } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $error_msg = "Please enter a valid email address.";
  } else {
    $insert_query = "INSERT INTO contact_messages (name, email, message) VALUES ('$name', '$email', '$message')";
    if (mysqli_query($conn, $insert_query)) {
      $message_sent = true;
    } else {
      $error_msg = "Error: Could not send message. Please try again.";
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Contact Us</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #111;
      color: #fff;
      margin: 0;
    }

    .contact-container {
      padding: 50px 20px;
      min-height: calc(100vh - 200px);
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .contact-container h1 {
      color: #ffb703;
      font-size: 36px;
      margin-bottom: 10px;
    }

    .contact-container>p {
      color: #ccc;
      margin-bottom: 30px;
      text-align: center;
    }

    .contact-form {
      background: #1c1c1c;
      max-width: 500px;
      width: 100%;
      padding: 30px;
      border-radius: 10px;
      text-align: left;
      border: 1px solid #333;
    }

    .input-group {
      margin-bottom: 20px;
    }

    .input-group label {
      display: block;
      color: #ffb703;
      margin-bottom: 8px;
      font-weight: bold;
    }

    .input-group input,
    .input-group textarea {
      width: 100%;
      padding: 12px;
      background: #2b2b2b;
      border: 1px solid #444;
      color: #fff;
      border-radius: 5px;
      font-size: 14px;
      transition: border-color 0.3s;
    }

    .input-group input:focus,
    .input-group textarea:focus {
      outline: none;
      border-color: #ffb703;
    }

    .input-group textarea {
      resize: vertical;
      height: 120px;
    }

    .submit-btn {
      width: 100%;
      padding: 12px;
      background: #e63946;
      color: white;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
      transition: 0.3s;
      font-weight: bold;
    }

    .submit-btn:hover {
      background: #ffb703;
      color: #111;
    }

    .alert {
      padding: 12px;
      margin-bottom: 20px;
      border-radius: 5px;
      text-align: center;
    }

    .alert.error {
      background: #4f1b1b;
      color: #ffdede;
      border: 1px solid #e63946;
    }

    /* Thank You Card */
    .thank-you-card {
      background: #1c1c1c;
      max-width: 500px;
      width: 100%;
      padding: 40px 30px;
      border-radius: 12px;
      text-align: center;
      border: 2px solid #2a2a2a;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
    }

    .thank-you-icon {
      font-size: 4rem;
      color: #22c55e;
      margin-bottom: 1.5rem;
      animation: scaleIn 0.5s ease;
    }

    @keyframes scaleIn {
      from {
        transform: scale(0);
        opacity: 0;
      }

      to {
        transform: scale(1);
        opacity: 1;
      }
    }

    .thank-you-card h2 {
      color: #ffb703;
      font-size: 2rem;
      margin-bottom: 1rem;
    }

    .thank-you-card p {
      color: #ccc;
      font-size: 1.1rem;
      line-height: 1.7;
      margin-bottom: 1.5rem;
    }

    .thank-you-buttons {
      display: flex;
      gap: 1rem;
      justify-content: center;
      flex-wrap: wrap;
    }

    .thank-you-buttons a {
      display: inline-block;
      padding: 0.9rem 2rem;
      border-radius: 8px;
      font-weight: bold;
      font-size: 1rem;
      text-decoration: none;
      transition: all 0.3s ease;
    }

    .btn-home {
      background: #e63946;
      color: #fff;
    }

    .btn-home:hover {
      background: #c82333;
      transform: translateY(-2px);
    }

    .btn-another {
      background: #333;
      color: #fff;
    }

    .btn-another:hover {
      background: #ffb703;
      color: #111;
      transform: translateY(-2px);
    }
  </style>
</head>

<body>

  <?php include 'Header.php'; ?>

  <div class="contact-container">

    <?php if ($message_sent): ?>
      <!-- Thank You Message -->
      <div class="thank-you-card">
        <div class="thank-you-icon">✅</div>
        <h2>Thank You!</h2>
        <p>Your message has been sent successfully. We appreciate your feedback and will get back to you soon!</p>
        <div class="thank-you-buttons">
          <a href="Home.php" class="btn-home">Back to Home</a>
          <a href="Contact.php" class="btn-another">Send Another</a>
        </div>
      </div>
    <?php else: ?>
      <!-- Contact Form -->
      <h1>Contact Us</h1>
      <p>We'd love to hear from you! Fill out the form below and we'll get back to you soon.</p>

      <div class="contact-form">
        <?php if ($error_msg): ?>
          <div class="alert error"><?= htmlspecialchars($error_msg) ?></div>
        <?php endif; ?>

        <form action="" method="POST">
          <div class="input-group">
            <label for="name">Full Name</label>
            <input type="text" name="name" id="name" placeholder="Enter your full name" required>
          </div>

          <div class="input-group">
            <label for="email">Email Address</label>
            <input type="email" name="email" id="email" placeholder="Enter your email" required>
          </div>

          <div class="input-group">
            <label for="message">Your Message</label>
            <textarea name="message" id="message" placeholder="Type your message here..." required></textarea>
          </div>

          <button type="submit" name="send_message" class="submit-btn">Send Message</button>
        </form>
      </div>
    <?php endif; ?>

  </div>

  <?php include 'Footer.php'; ?>

</body>

</html>