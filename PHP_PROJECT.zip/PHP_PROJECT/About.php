<?php
require_once 'auth_check.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      background: #111;
      color: #fff;
      line-height: 1.6;
    }

    /* Hero Section */
    .hero-about {
      background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)),
        url("Images/Background.png") center/cover no-repeat;
      text-align: center;
      padding: 6rem 2rem;
      position: relative;
      min-height: 400px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .hero-content-about {
      position: relative;
      z-index: 1;
    }

    .hero-content-about h1 {
      font-size: 3.5rem;
      color: #ffb703;
      margin-bottom: 1rem;
      animation: fadeInDown 1s ease;
    }

    .hero-content-about p {
      font-size: 1.3rem;
      margin-top: 1rem;
      color: #f1f1f1;
      animation: fadeInUp 1.2s ease;
    }

    @keyframes fadeInDown {
      from {
        opacity: 0;
        transform: translateY(-30px);
      }

      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }

      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    /* About Section */
    .about-section {
      padding: 4rem 2rem;
      text-align: center;
      background: #1c1c1c;
    }

    .about-section h2 {
      color: #e63946;
      margin-bottom: 1.5rem;
      font-size: 2.5rem;
    }

    .about-section p {
      max-width: 900px;
      margin: 0 auto;
      color: #ddd;
      font-size: 1.15rem;
      line-height: 1.8;
    }

    /* Mission Section */
    .mission-section {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 2rem;
      padding: 4rem 2rem;
      background: #111;
      max-width: 1200px;
      margin: 0 auto;
    }

    .mission-box {
      background: #1c1c1c;
      padding: 2.5rem;
      border-radius: 12px;
      text-align: center;
      transition: all 0.3s ease;
      border: 2px solid #2a2a2a;
    }

    .mission-box:hover {
      background: #252525;
      transform: translateY(-10px);
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.5);
      border-color: #ffb703;
    }

    .mission-box h3 {
      color: #ffb703;
      margin-bottom: 1rem;
      font-size: 1.8rem;
    }

    .mission-box p {
      color: #ccc;
      font-size: 1.1rem;
      line-height: 1.7;
    }

    .about-section,
    .mission-section {
      opacity: 0;
      transform: translateY(30px);
      transition: all 0.8s ease;
    }

    .visible {
      opacity: 1;
      transform: translateY(0);
    }

    /* Responsive */
    @media (max-width: 768px) {
      .hero-content-about h1 {
        font-size: 2.5rem;
      }

      .hero-content-about p {
        font-size: 1.1rem;
      }

      .about-section h2 {
        font-size: 2rem;
      }

      .about-section p {
        font-size: 1rem;
      }

      .mission-section {
        grid-template-columns: 1fr;
        padding: 3rem 1.5rem;
      }
    }
  </style>
</head>

<body>

  <?php include 'Header.php'; ?>

  <!-- Hero -->
  <section class="hero-about">
    <div class="hero-content-about">
      <h1>About Us</h1>
      <p>Delicious food, made with love and delivered with care.</p>
    </div>
  </section>

  <!-- About -->
  <section class="about-section">
    <h2>Who We Are</h2>
    <p>
      We are passionate food lovers bringing you the best flavors from across India and beyond.
      From spicy Punjabi curries to authentic Gujarati dishes, sizzling Chinese, and cheesy pizzas —
      our mission is to satisfy every craving with freshness, quality, and love.
    </p>
  </section>

  <!-- Mission -->
  <section class="mission-section">
    <div class="mission-box">
      <h3>Our Mission</h3>
      <p>To serve hygienic, tasty, and affordable meals that make you smile every day.</p>
    </div>
    <div class="mission-box">
      <h3>Our Vision</h3>
      <p>To become the most loved food platform by connecting people through taste and tradition.</p>
    </div>
  </section>

  <?php include 'Footer.php'; ?>

  <script>
    document.addEventListener("DOMContentLoaded", function() {
      const sections = document.querySelectorAll(".about-section, .mission-section");

      const revealOnScroll = () => {
        const triggerBottom = window.innerHeight * 0.85;
        sections.forEach(sec => {
          const rect = sec.getBoundingClientRect();
          if (rect.top < triggerBottom) {
            sec.classList.add("visible");
          }
        });
      };

      window.addEventListener("scroll", revealOnScroll);
      revealOnScroll();
    });

    // Scroll-to-top button
    const scrollBtn = document.createElement("button");
    scrollBtn.innerText = "↑";
    scrollBtn.id = "scrollTopBtn";
    document.body.appendChild(scrollBtn);

    scrollBtn.style.cssText = `
      position: fixed;
      bottom: 30px;
      right: 30px;
      background: #ffb703;
      color: #111;
      border: none;
      padding: 12px 16px;
      border-radius: 50%;
      font-size: 20px;
      cursor: pointer;
      display: none;
      transition: all 0.3s ease;
      z-index: 999;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
    `;

    window.addEventListener("scroll", () => {
      if (window.scrollY > 300) {
        scrollBtn.style.display = "block";
      } else {
        scrollBtn.style.display = "none";
      }
    });

    scrollBtn.addEventListener("click", () => {
      window.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    });
  </script>
</body>

</html>