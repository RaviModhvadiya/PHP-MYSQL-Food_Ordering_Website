<?php
require_once 'config.php';
require_once 'auth_check.php';

if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

if (empty($_SESSION['user_id'])) {
  header('Location: Auth/login.php');
  exit();
}

$user_id = intval($_SESSION['user_id']);
$user = [
  'name' => 'User',
  'email' => 'Not provided',
  'created_at' => '',
  'profile_picture' => 'Images/Profilepic.png'
];

$stmt = mysqli_prepare($conn, "SELECT id, name, email, created_at, profile_picture FROM users WHERE id = ?");
if ($stmt) {
  mysqli_stmt_bind_param($stmt, "i", $user_id);
  mysqli_stmt_execute($stmt);
  $res = mysqli_stmt_get_result($stmt);
  $f = mysqli_fetch_assoc($res);
  if ($f) {
    $user['name'] = $f['name'] ?? $user['name'];
    $user['email'] = $f['email'] ?? $user['email'];
    $user['created_at'] = $f['created_at'] ?? $user['created_at'];
    $user['profile_picture'] = $f['profile_picture'] ?? $user['profile_picture'];
  }
  mysqli_stmt_close($stmt);
}

// If profile picture doesn't exist, use default
if (empty($user['profile_picture']) || !file_exists($user['profile_picture'])) {
  $user['profile_picture'] = 'Images/Profilepic.png';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Profile</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      background: #111;
      color: #fff;
    }

    main {
      max-width: 950px;
      margin: 2rem auto;
      padding: 0 1.5rem;
      min-height: calc(100vh - 300px);
    }

    h1 {
      text-align: center;
      color: #ffb703;
      margin-bottom: 2.5rem;
      font-size: 2.5rem;
    }

    .profile-card {
      background: #1c1c1c;
      padding: 2.5rem;
      border-radius: 12px;
      text-align: center;
      margin-bottom: 2rem;
      border: 2px solid #2a2a2a;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
    }

    .profile-card img {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      border: 4px solid #ffb703;
      object-fit: cover;
      margin: 0 auto 1.5rem;
    }

    .profile-card h2 {
      margin: 0.5rem 0;
      color: #ffb703;
      font-size: 1.8rem;
    }

    .profile-card p {
      margin: 0.5rem 0;
      color: #ccc;
      font-size: 1rem;
    }

    .profile-buttons {
      margin-top: 1.5rem;
      display: flex;
      justify-content: center;
      gap: 1rem;
      flex-wrap: wrap;
    }

    .profile-buttons a {
      text-decoration: none;
    }

    .profile-buttons button {
      background: #e63946;
      color: #fff;
      border: none;
      padding: 0.8rem 1.8rem;
      border-radius: 8px;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.3s ease;
      font-weight: bold;
    }

    .profile-buttons button:hover {
      background: #c82333;
      transform: translateY(-2px);
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
    }

    .info-section {
      background: #1c1c1c;
      padding: 2rem;
      border-radius: 12px;
      margin-bottom: 2rem;
      border: 2px solid #2a2a2a;
    }

    .info-section h3 {
      margin-bottom: 1.5rem;
      color: #ffb703;
      font-size: 1.6rem;
    }

    .info-item {
      margin-bottom: 1rem;
      padding-bottom: 1rem;
      border-bottom: 1px solid #333;
    }

    .info-item:last-child {
      border-bottom: none;
      margin-bottom: 0;
    }

    .info-item strong {
      color: #ffb703;
      display: inline-block;
      min-width: 140px;
      font-size: 1rem;
    }

    @media (max-width: 768px) {
      .profile-buttons {
        flex-direction: column;
        align-items: stretch;
      }

      .profile-buttons button {
        width: 100%;
      }
    }

    @media (max-width: 600px) {
      .info-item {
        display: flex;
        flex-direction: column;
        gap: 0.3rem;
      }

      .info-item strong {
        min-width: auto;
      }
    }
  </style>
</head>

<body>

  <?php include 'Header.php'; ?>

  <main>
    <h1>User Profile</h1>

    <div class="profile-card">
      <img src="<?= htmlspecialchars($user['profile_picture']) ?>" alt="User Avatar">
      <h2><?= htmlspecialchars($user['name']) ?></h2>
      <p><?= htmlspecialchars($user['email']) ?></p>
      <p>Member Since: <?= $user['created_at'] ? htmlspecialchars(date('Y', strtotime($user['created_at']))) : 'N/A' ?></p>

      <div class="profile-buttons">
        <a href="profile_edit.php"><button>Edit Profile</button></a>
        <a href="change_password.php"><button>Change Password</button></a>
        <a href="Auth/logout.php"><button>Logout</button></a>
      </div>
    </div>

    <div class="info-section">
      <h3>Personal Information</h3>
      <div class="info-item">
        <strong>Full Name:</strong> <?= htmlspecialchars($user['name']) ?>
      </div>
      <div class="info-item">
        <strong>Email:</strong> <?= htmlspecialchars($user['email']) ?>
      </div>
    </div>

  </main>

  <?php include 'Footer.php'; ?>
</body>

</html>