<?php
require_once 'config.php';
require_once 'auth_check.php';

if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

if (empty($_SESSION['user_id'])) {
  header('Location: Auth/login.php');
  exit();
}

$user_id = intval($_SESSION['user_id']);
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $current_password = $_POST['current_password'] ?? '';
  $new_password = $_POST['new_password'] ?? '';
  $confirm_password = $_POST['confirm_password'] ?? '';

  if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
    $error = "All fields are required.";
  } elseif ($new_password !== $confirm_password) {
    $error = "New passwords do not match.";
  } elseif (strlen($new_password) < 6) {
    $error = "Password must be at least 6 characters long.";
  } else {
    // Verify current password
    $stmt = mysqli_prepare($conn, "SELECT password FROM users WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    if ($user && password_verify($current_password, $user['password'])) {
      // Update password
      $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
      $stmt = mysqli_prepare($conn, "UPDATE users SET password = ? WHERE id = ?");
      mysqli_stmt_bind_param($stmt, "si", $hashed_password, $user_id);

      if (mysqli_stmt_execute($stmt)) {
        $success = "Password changed successfully!";
        $_POST = []; // Clear form
      } else {
        $error = "Failed to change password.";
      }
      mysqli_stmt_close($stmt);
    } else {
      $error = "Current password is incorrect.";
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Change Password</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      background: #111;
      color: #fff;
    }

    main {
      max-width: 600px;
      margin: 2rem auto;
      padding: 0 1.5rem;
      min-height: calc(100vh - 300px);
    }

    h1 {
      text-align: center;
      color: #ffb703;
      margin-bottom: 2rem;
      font-size: 2.5rem;
    }

    .password-form {
      background: #1c1c1c;
      padding: 2.5rem;
      border-radius: 12px;
      border: 2px solid #2a2a2a;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
    }

    .form-group {
      margin-bottom: 1.5rem;
    }

    .form-group label {
      display: block;
      margin-bottom: 0.6rem;
      font-weight: bold;
      color: #ffb703;
      font-size: 1rem;
    }

    .form-group input {
      width: 100%;
      padding: 0.9rem;
      border-radius: 8px;
      border: 2px solid #333;
      background: #252525;
      color: #fff;
      font-size: 1rem;
      transition: all 0.3s ease;
    }

    .form-group input:focus {
      outline: none;
      border-color: #ffb703;
      background: #2a2a2a;
    }

    .message {
      padding: 1rem;
      margin-bottom: 1.5rem;
      border-radius: 8px;
      font-size: 1rem;
    }

    .message.success {
      background: #1b4f2b;
      color: #dfffe6;
      border: 2px solid #22c55e;
    }

    .message.error {
      background: #4f1b1b;
      color: #ffdede;
      border: 2px solid #e63946;
    }

    .form-buttons {
      display: flex;
      gap: 1rem;
      margin-top: 2rem;
    }

    .form-buttons button,
    .form-buttons a {
      flex: 1;
      padding: 1rem;
      border-radius: 8px;
      font-size: 1.1rem;
      font-weight: bold;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s ease;
      border: none;
      text-decoration: none;
      display: inline-block;
    }

    .btn-save {
      background: #e63946;
      color: #fff;
    }

    .btn-save:hover {
      background: #c82333;
      transform: translateY(-2px);
    }

    .btn-cancel {
      background: #333;
      color: #fff;
    }

    .btn-cancel:hover {
      background: #444;
      transform: translateY(-2px);
    }

    .password-info {
      margin-top: 0.5rem;
      font-size: 0.9rem;
      color: #888;
    }

    @media (max-width: 600px) {
      .form-buttons {
        flex-direction: column;
      }

      .password-form {
        padding: 2rem;
      }
    }
  </style>
</head>

<body>

  <?php include 'Header.php'; ?>

  <main>
    <h1>Change Password</h1>

    <form class="password-form" method="POST">
      <?php if ($success): ?>
        <div class="message success"><?= htmlspecialchars($success) ?></div>
      <?php endif; ?>

      <?php if ($error): ?>
        <div class="message error"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <div class="form-group">
        <label for="current_password">Current Password</label>
        <input type="password" id="current_password" name="current_password"
          placeholder="Enter your current password" required>
      </div>

      <div class="form-group">
        <label for="new_password">New Password</label>
        <input type="password" id="new_password" name="new_password"
          placeholder="Enter your new password" required>
        <div class="password-info">Must be at least 6 characters long</div>
      </div>

      <div class="form-group">
        <label for="confirm_password">Confirm New Password</label>
        <input type="password" id="confirm_password" name="confirm_password"
          placeholder="Confirm your new password" required>
      </div>

      <div class="form-buttons">
        <button type="submit" class="btn-save">Change Password</button>
        <a href="Profile.php" class="btn-cancel">Back</a>
      </div>
    </form>
  </main>

  <?php include 'Footer.php'; ?>

</body>

</html>