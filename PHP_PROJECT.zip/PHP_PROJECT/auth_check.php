<?php
// auth_check.php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

$current_page = basename($_SERVER['PHP_SELF']);

// Pages that don't require authentication
$public_pages = ['index.php'];

$is_public_page = in_array($current_page, $public_pages);

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id']) && !$is_public_page) {
  header("Location: index.php");
  exit();
}
