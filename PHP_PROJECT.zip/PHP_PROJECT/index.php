<?php
session_start();

if (isset($_SESSION['user_id'])) {
  header("Location: Home.php");
  exit();
}

$conn = mysqli_connect("localhost", "root", "", "food_website");

if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$active_tab = 'login';
$login_errors = [];
$register_errors = [];
$register_success = '';

$old_login_email = '';
$old_register_name = '';
$old_register_email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

  // Login Logic
  if (isset($_POST['login'])) {
    $email = trim($_POST['login_email'] ?? '');
    $password = $_POST['login_password'] ?? '';
    $old_login_email = $email;

    if (empty($email)) {
      $login_errors['email'] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $login_errors['email'] = "Please enter a valid email";
    }

    if (empty($password)) {
      $login_errors['password'] = "Password is required";
    }

    if (empty($login_errors)) {
      $stmt = mysqli_prepare($conn, "SELECT id, name, password FROM users WHERE email = ?");
      mysqli_stmt_bind_param($stmt, "s", $email);
      mysqli_stmt_execute($stmt);
      $result = mysqli_stmt_get_result($stmt);

      if ($result && $user = mysqli_fetch_assoc($result)) {
        if (password_verify($password, $user['password'])) {
          $_SESSION['user_id'] = $user['id'];
          $_SESSION['user_name'] = $user['name'];
          header("Location: Home.php");
          exit();
        } else {
          $login_errors['password'] = "Invalid email or password";
        }
      } else {
        $login_errors['email'] = "No account found with this email";
      }
      mysqli_stmt_close($stmt);
    }
  }

  // Register Logic
  if (isset($_POST['register'])) {
    $active_tab = 'register';
    $name = trim($_POST['register_name'] ?? '');
    $email = trim($_POST['register_email'] ?? '');
    $password = $_POST['register_password'] ?? '';
    $confirm = $_POST['register_confirm_password'] ?? '';

    $old_register_name = $name;
    $old_register_email = $email;

    if (empty($name)) {
      $register_errors['name'] = "Name is required";
    } elseif (strlen($name) < 2) {
      $register_errors['name'] = "Name must be at least 2 characters";
    }

    if (empty($email)) {
      $register_errors['email'] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $register_errors['email'] = "Please enter a valid email";
    } else {
      $stmt = mysqli_prepare($conn, "SELECT id FROM users WHERE email = ?");
      mysqli_stmt_bind_param($stmt, "s", $email);
      mysqli_stmt_execute($stmt);
      $result = mysqli_stmt_get_result($stmt);
      if ($result && mysqli_num_rows($result) > 0) {
        $register_errors['email'] = "Email already exists";
      }
      mysqli_stmt_close($stmt);
    }

    if (empty($password)) {
      $register_errors['password'] = "Password is required";
    } elseif (strlen($password) < 6) {
      $register_errors['password'] = "Minimum 6 characters required";
    }

    if (empty($confirm)) {
      $register_errors['confirm'] = "Please confirm your password";
    } elseif ($password !== $confirm) {
      $register_errors['confirm'] = "Passwords do not match";
    }

    if (empty($register_errors)) {
      $hashed = password_hash($password, PASSWORD_DEFAULT);
      $insert_stmt = mysqli_prepare($conn, "INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
      mysqli_stmt_bind_param($insert_stmt, "sss", $name, $email, $hashed);

      if (mysqli_stmt_execute($insert_stmt)) {
        $register_success = "Registration successful! Please login.";
        $active_tab = 'login';
        $old_register_name = '';
        $old_register_email = '';
      } else {
        $register_errors['general'] = "Registration failed. Please try again.";
      }
      mysqli_stmt_close($insert_stmt);
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - Food Website</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      background: #111;
      color: #fff;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    /* Top header (new) */
    .site-top-header {
      width: 100%;
      background: linear-gradient(90deg, rgba(255, 183, 3, 0.06), rgba(255, 183, 3, 0.02));
      padding: 28px 20px;
      text-align: center;
      border-bottom: 1px solid rgba(255, 183, 3, 0.05);
      box-shadow: 0 4px 18px rgba(0, 0, 0, 0.18);
    }

    .top-header-container {
      max-width: 1100px;
      margin: 0 auto;
    }

    .welcome-title {
      font-size: 48px;
      font-weight: 700;
      color: #ffb703;
      margin: 0 0 6px 0;
      letter-spacing: 1px;
      text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.45);
    }

    .welcome-subtitle {
      font-size: 16px;
      color: #bfbfbf;
      margin: 0;
      opacity: 0.95;
    }

    /* Keep form nicely spaced under header */
    .main-wrapper {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 40px 20px;
      margin-top: 12px;
    }

    @media (max-width: 720px) {
      .welcome-title {
        font-size: 28px;
      }

      .welcome-subtitle {
        font-size: 14px;
      }

      .site-top-header {
        padding: 18px 12px;
      }
    }

    .form-card {
      background: #1c1c1c;
      border-radius: 12px;
      width: 100%;
      max-width: 400px;
      padding: 40px 35px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
    }

    /* Tabs */
    .tabs {
      display: flex;
      margin-bottom: 30px;
      border-bottom: 2px solid #333;
    }

    .tab-btn {
      flex: 1;
      background: none;
      border: none;
      padding: 12px;
      font-size: 16px;
      color: #888;
      cursor: pointer;
      position: relative;
    }

    .tab-btn.active {
      color: #ffb703;
    }

    .tab-btn.active::after {
      content: '';
      position: absolute;
      bottom: -2px;
      left: 0;
      width: 100%;
      height: 2px;
      background: #ffb703;
    }

    /* Forms */
    .form-content {
      display: none;
    }

    .form-content.active {
      display: block;
    }

    .input-group {
      margin-bottom: 8px;
    }

    .input-group label {
      display: block;
      font-size: 13px;
      color: #aaa;
      margin-bottom: 6px;
    }

    .input-group input {
      width: 100%;
      padding: 12px 14px;
      background: #2a2a2a;
      border: 1px solid #333;
      border-radius: 6px;
      color: #fff;
      font-size: 14px;
      outline: none;
    }

    .input-group input:focus {
      border-color: #ffb703;
    }

    .input-group input.error {
      border-color: #e63946;
    }

    .error-text {
      color: #e63946;
      font-size: 12px;
      margin-top: 4px;
      min-height: 18px;
    }

    .success-box {
      background: #0f2f1a;
      border: 1px solid #2a8;
      color: #4dff88;
      padding: 12px;
      border-radius: 6px;
      margin-bottom: 20px;
      font-size: 14px;
      text-align: center;
    }

    .error-box {
      background: #2f0f0f;
      border: 1px solid #a33;
      color: #ff6b6b;
      padding: 12px;
      border-radius: 6px;
      margin-bottom: 20px;
      font-size: 14px;
      text-align: center;
    }

    .submit-btn {
      width: 100%;
      padding: 14px;
      background: #e63946;
      border: none;
      border-radius: 6px;
      color: #fff;
      font-size: 15px;
      font-weight: 600;
      cursor: pointer;
      margin-top: 10px;
    }

    .submit-btn:hover {
      background: #c82333;
    }

    /* Footer */
    .site-footer {
      background: #0a0a0a;
      padding: 30px 20px;
      text-align: center;
      border-top: 1px solid #222;
    }

    .footer-content {
      max-width: 800px;
      margin: 0 auto;
    }

    .copyright {
      color: #888;
      font-size: 14px;
      margin-bottom: 15px;
    }

    .footer-links {
      margin-bottom: 15px;
    }

    .footer-links a {
      color: #ffb703;
      text-decoration: none;
      margin: 0 10px;
      font-size: 14px;
    }

    .footer-links a:hover {
      text-decoration: underline;
    }

    .footer-social a {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      background: #333;
      color: #fff;
      border-radius: 50%;
      margin: 0 5px;
      text-decoration: none;
    }

    .footer-social a:hover {
      background: #ffb703;
      color: #000;
    }
  </style>
</head>

<body>
  <!-- Top header: centered, full width -->
  <header class="site-top-header" role="banner">
    <div class="top-header-container">
      <h1 class="welcome-title">Welcome to Our Food Website</h1>
      <p class="welcome-subtitle">Discover delicious meals and unforgettable flavors</p>
    </div>
  </header>

  <div class="main-wrapper">
    <div class="form-card">
      <div class="tabs">
        <button class="tab-btn <?php echo $active_tab === 'login' ? 'active' : ''; ?>" data-tab="login">Sign In</button>
        <button class="tab-btn <?php echo $active_tab === 'register' ? 'active' : ''; ?>" data-tab="register">Sign Up</button>
      </div>

      <!-- Login Form -->
      <div class="form-content <?php echo $active_tab === 'login' ? 'active' : ''; ?>" id="login">
        <?php if ($register_success): ?>
          <div class="success-box"><?php echo htmlspecialchars($register_success); ?></div>
        <?php endif; ?>

        <form method="POST">
          <div class="input-group">
            <label>Email</label>
            <input type="email" name="login_email"
              class="<?php echo isset($login_errors['email']) ? 'error' : ''; ?>"
              value="<?php echo htmlspecialchars($old_login_email); ?>">
            <div class="error-text"><?php echo $login_errors['email'] ?? ''; ?></div>
          </div>

          <div class="input-group">
            <label>Password</label>
            <input type="password" name="login_password"
              class="<?php echo isset($login_errors['password']) ? 'error' : ''; ?>">
            <div class="error-text"><?php echo $login_errors['password'] ?? ''; ?></div>
          </div>

          <button type="submit" name="login" class="submit-btn">Sign In</button>
        </form>
      </div>

      <!-- Register Form -->
      <div class="form-content <?php echo $active_tab === 'register' ? 'active' : ''; ?>" id="register">
        <?php if (isset($register_errors['general'])): ?>
          <div class="error-box"><?php echo htmlspecialchars($register_errors['general']); ?></div>
        <?php endif; ?>

        <form method="POST">
          <div class="input-group">
            <label>Name</label>
            <input type="text" name="register_name"
              class="<?php echo isset($register_errors['name']) ? 'error' : ''; ?>"
              value="<?php echo htmlspecialchars($old_register_name); ?>">
            <div class="error-text"><?php echo $register_errors['name'] ?? ''; ?></div>
          </div>

          <div class="input-group">
            <label>Email</label>
            <input type="email" name="register_email"
              class="<?php echo isset($register_errors['email']) ? 'error' : ''; ?>"
              value="<?php echo htmlspecialchars($old_register_email); ?>">
            <div class="error-text"><?php echo $register_errors['email'] ?? ''; ?></div>
          </div>

          <div class="input-group">
            <label>Password</label>
            <input type="password" name="register_password"
              class="<?php echo isset($register_errors['password']) ? 'error' : ''; ?>">
            <div class="error-text"><?php echo $register_errors['password'] ?? ''; ?></div>
          </div>

          <div class="input-group">
            <label>Confirm Password</label>
            <input type="password" name="register_confirm_password"
              class="<?php echo isset($register_errors['confirm']) ? 'error' : ''; ?>">
            <div class="error-text"><?php echo $register_errors['confirm'] ?? ''; ?></div>
          </div>

          <button type="submit" name="register" class="submit-btn">Sign Up</button>
        </form>
      </div>
    </div>
  </div>

  <footer class="site-footer">
    <div class="footer-content">
      <p class="copyright">&copy; 2025 Our Food Website. All rights reserved.</p>
      <div class="footer-links">
        <a href="#">About Us</a>
        <a href="#">Contact</a>
        <a href="#">Privacy Policy</a>
        <a href="#">Terms</a>
      </div>
      <div class="footer-social">
        <a href="#"><i class="fab fa-facebook-f"></i></a>
        <a href="#"><i class="fab fa-instagram"></i></a>
        <a href="#"><i class="fab fa-twitter"></i></a>
        <a href="#"><i class="fab fa-linkedin-in"></i></a>
      </div>
    </div>
  </footer>

  <script>
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.form-content').forEach(f => f.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById(btn.dataset.tab).classList.add('active');
      });
    });
  </script>
</body>

</html>
<?php
if (isset($conn)) mysqli_close($conn);
?>