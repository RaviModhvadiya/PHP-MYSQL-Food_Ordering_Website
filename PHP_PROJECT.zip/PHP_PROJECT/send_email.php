<?php
session_start();
require 'config.php'; // Include database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = trim($_POST['name']);
  $email = trim($_POST['email']);
  $message = trim($_POST['message']);

  if (!empty($name) && !empty($email) && !empty($message) && filter_var($email, FILTER_VALIDATE_EMAIL)) {

    // Prepare SQL statement to insert data
    $stmt = mysqli_prepare($conn, "INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)");

    if ($stmt) {
      mysqli_stmt_bind_param($stmt, "sss", $name, $email, $message);

      if (mysqli_stmt_execute($stmt)) {
        $_SESSION['contact_msg'] = "Thank you! Your message has been saved.";
      } else {
        $_SESSION['contact_msg'] = "Error saving your message. Please try again.";
        $_SESSION['contact_error'] = true;
      }
      mysqli_stmt_close($stmt);
    } else {
      $_SESSION['contact_msg'] = "Database error. Please try again later.";
      $_SESSION['contact_error'] = true;
    }
  } else {
    $_SESSION['contact_msg'] = "Please fill out all fields correctly.";
    $_SESSION['contact_error'] = true;
  }
}

header("Location: Contact.php");
exit();
