<?php
require_once 'config.php';
require_once 'auth_check.php';

if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

if (empty($_SESSION['user_id'])) {
  header('Location: Auth/login.php');
  exit();
}

$user_id = intval($_SESSION['user_id']);
$success = '';
$error = '';

// Fetch current user data
$stmt = mysqli_prepare($conn, "SELECT name, email, profile_picture FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$user) {
  header('Location: Auth/login.php');
  exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = mysqli_real_escape_string($conn, trim($_POST['name'] ?? ''));
  $current_picture = $user['profile_picture'];

  if (empty($name)) {
    $error = "Name is required.";
  } else {
    // Handle image upload
    $upload_path = $current_picture;

    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
      $allowed_types = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif'];
      $max_size = 5 * 1024 * 1024; // 5MB

      $file_type = $_FILES['profile_picture']['type'];
      $file_size = $_FILES['profile_picture']['size'];

      if (!in_array($file_type, $allowed_types)) {
        $error = "Only JPG, JPEG, PNG, and GIF files are allowed.";
      } elseif ($file_size > $max_size) {
        $error = "File size must be less than 5MB.";
      } else {
        // Create uploads directory if it doesn't exist
        $upload_dir = 'uploads/profiles/';
        if (!file_exists($upload_dir)) {
          mkdir($upload_dir, 0755, true);
        }

        // Generate unique filename
        $extension = pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION);
        $filename = 'profile_' . $user_id . '_' . time() . '.' . $extension;
        $upload_path = $upload_dir . $filename;

        // Delete old profile picture if exists
        if ($current_picture && file_exists($current_picture) && $current_picture !== 'Images/Profilepic.png') {
          unlink($current_picture);
        }

        // Move uploaded file
        if (!move_uploaded_file($_FILES['profile_picture']['tmp_name'], $upload_path)) {
          $error = "Failed to upload image.";
          $upload_path = $current_picture;
        }
      }
    }

    if (empty($error)) {
      $stmt = mysqli_prepare($conn, "UPDATE users SET name = ?, profile_picture = ? WHERE id = ?");
      mysqli_stmt_bind_param($stmt, "ssi", $name, $upload_path, $user_id);

      if (mysqli_stmt_execute($stmt)) {
        $_SESSION['user_name'] = $name;
        $success = "Profile updated successfully!";
        $user['name'] = $name;
        $user['profile_picture'] = $upload_path;
      } else {
        $error = "Failed to update profile.";
      }
      mysqli_stmt_close($stmt);
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Profile</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      background: #111;
      color: #fff;
    }

    main {
      max-width: 700px;
      margin: 2rem auto;
      padding: 0 1.5rem;
      min-height: calc(100vh - 300px);
    }

    h1 {
      text-align: center;
      color: #ffb703;
      margin-bottom: 2rem;
      font-size: 2.5rem;
    }

    .edit-form {
      background: #1c1c1c;
      padding: 2.5rem;
      border-radius: 12px;
      border: 2px solid #2a2a2a;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
    }

    .profile-preview {
      text-align: center;
      margin-bottom: 2rem;
    }

    .profile-preview img {
      width: 150px;
      height: 150px;
      border-radius: 50%;
      border: 4px solid #ffb703;
      object-fit: cover;
      margin: 0 auto 1rem;
    }

    .form-group {
      margin-bottom: 1.5rem;
    }

    .form-group label {
      display: block;
      margin-bottom: 0.6rem;
      font-weight: bold;
      color: #ffb703;
      font-size: 1rem;
    }

    .form-group input[type="text"],
    .form-group input[type="file"] {
      width: 100%;
      padding: 0.9rem;
      border-radius: 8px;
      border: 2px solid #333;
      background: #252525;
      color: #fff;
      font-size: 1rem;
      transition: all 0.3s ease;
    }

    .form-group input:focus {
      outline: none;
      border-color: #ffb703;
      background: #2a2a2a;
    }

    .form-group input[type="file"] {
      padding: 0.7rem;
      cursor: pointer;
    }

    .file-info {
      margin-top: 0.5rem;
      font-size: 0.9rem;
      color: #888;
    }

    .message {
      padding: 1rem;
      margin-bottom: 1.5rem;
      border-radius: 8px;
      font-size: 1rem;
    }

    .message.success {
      background: #1b4f2b;
      color: #dfffe6;
      border: 2px solid #22c55e;
    }

    .message.error {
      background: #4f1b1b;
      color: #ffdede;
      border: 2px solid #e63946;
    }

    .form-buttons {
      display: flex;
      gap: 1rem;
      margin-top: 2rem;
    }

    .form-buttons button,
    .form-buttons a {
      flex: 1;
      padding: 1rem;
      border-radius: 8px;
      font-size: 1.1rem;
      font-weight: bold;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s ease;
      border: none;
      text-decoration: none;
      display: inline-block;
    }

    .btn-save {
      background: #e63946;
      color: #fff;
    }

    .btn-save:hover {
      background: #c82333;
      transform: translateY(-2px);
    }

    .btn-cancel {
      background: #333;
      color: #fff;
    }

    .btn-cancel:hover {
      background: #444;
      transform: translateY(-2px);
    }

    @media (max-width: 600px) {
      .form-buttons {
        flex-direction: column;
      }

      .edit-form {
        padding: 2rem;
      }
    }
  </style>
</head>

<body>

  <?php include 'Header.php'; ?>

  <main>
    <h1>Edit Profile</h1>

    <form class="edit-form" method="POST" enctype="multipart/form-data">
      <?php if ($success): ?>
        <div class="message success"><?= htmlspecialchars($success) ?></div>
      <?php endif; ?>

      <?php if ($error): ?>
        <div class="message error"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <div class="profile-preview">
        <img id="preview"
          src="<?= htmlspecialchars($user['profile_picture'] ?? 'Images/Profilepic.png') ?>"
          alt="Profile Picture">
      </div>

      <div class="form-group">
        <label for="name">Full Name</label>
        <input type="text" id="name" name="name"
          value="<?= htmlspecialchars($user['name']) ?>" required>
      </div>

      <div class="form-group">
        <label for="profile_picture">Profile Picture</label>
        <input type="file" id="profile_picture" name="profile_picture"
          accept="image/jpeg,image/jpg,image/png,image/gif">
        <div class="file-info">Allowed: JPG, PNG, GIF (Max: 5MB)</div>
      </div>

      <div class="form-buttons">
        <button type="submit" class="btn-save">Save Changes</button>
        <a href="Profile.php" class="btn-cancel">Back</a>
      </div>
    </form>
  </main>

  <?php include 'Footer.php'; ?>

  <script>
    // Image preview
    document.getElementById('profile_picture').addEventListener('change', function(e) {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function(event) {
          document.getElementById('preview').src = event.target.result;
        };
        reader.readAsDataURL(file);
      }
    });
  </script>

</body>

</html>