<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

// Get current page name
$current_page = basename($_SERVER['PHP_SELF']);

// Function to check if link is active
function isActive($pages)
{
  global $current_page;
  if (is_array($pages)) {
    return in_array($current_page, $pages) ? 'active' : '';
  }
  return ($current_page === $pages) ? 'active' : '';
}

if (!defined('CORE_ASSETS_INCLUDED')) {
  define('CORE_ASSETS_INCLUDED', true);
  echo '<link rel="stylesheet" href="style.css">';
  echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">';
}
?>

<style>
  .nav-links a.active {
    background: #ffb703;
    color: #111 !important;
  }

  .nav-links a.active:hover {
    background: #e6a502;
    color: #111 !important;
    transform: none;
  }
</style>

<nav class="navbar">
  <div class="logo">Our <span class="highlight">Food Site</span></div>

  <div class="menu-toggle" id="menuToggle">
    <i class="fas fa-bars"></i>
  </div>

  <ul class="nav-links" id="navLinks">
    <li><a href="Home.php" class="<?= isActive('Home.php') ?>"><i class="fas fa-home"></i> Home</a></li>
    <li><a href="Category.php" class="<?= isActive('Category.php') ?>"><i class="fas fa-utensils"></i> Menu</a></li>
    <?php if (!isset($_SESSION['user_id'])): ?>
      <li><a href="index.php" class="<?= isActive('index.php') ?>"><i class="fas fa-sign-in-alt"></i> Login</a></li>
    <?php else: ?>
      <li><a href="Profile.php" class="<?= isActive(['Profile.php', 'profile_edit.php', 'change_password.php']) ?>"><i class="fas fa-user"></i> Profile</a></li>
    <?php endif; ?>
    <li><a href="About.php" class="<?= isActive('About.php') ?>"><i class="fas fa-info-circle"></i> About</a></li>
    <li><a href="Contact.php" class="<?= isActive('Contact.php') ?>"><i class="fas fa-envelope"></i> Feedback</a></li>
    <li><a href="Cart.php" class="<?= isActive(['Cart.php', 'Checkout.php', 'OrderSuccess.php']) ?>"><i class="fas fa-shopping-cart"></i> Cart</a></li>
  </ul>
</nav>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.getElementById('menuToggle');
    const navLinks = document.getElementById('navLinks');

    if (menuToggle && navLinks) {
      menuToggle.addEventListener('click', () => {
        navLinks.classList.toggle('active');
      });

      document.addEventListener('click', (e) => {
        if (!menuToggle.contains(e.target) && !navLinks.contains(e.target)) {
          navLinks.classList.remove('active');
        }
      });
    }
  });
</script>