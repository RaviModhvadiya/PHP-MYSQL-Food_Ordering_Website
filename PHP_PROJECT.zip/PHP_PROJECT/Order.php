<?php
// Order page removed — redirect to home
header("Location: Home.php");
exit();
