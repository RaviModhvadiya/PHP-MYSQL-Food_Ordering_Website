<?php
require_once 'auth_check.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home - Our Food Website</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>

  <?php include 'Header.php'; ?>

  <!-- HERO SECTION -->
  <section id="home-hero" class="hero-section">
    <div class="hero-content">
      <h1>Welcome to Our Food Website</h1>
      <p>Order your favorite food from anywhere, anytime!</p>
      <div class="hero-buttons">
        <a href="Category.php">Order Now</a>
        <a href="Category.php">Explore Menu</a>
      </div>
    </div>
  </section>

  <!-- ABOUT SECTION -->
  <section id="home-about" class="about-section">
    <h2>About Our Website</h2>
    <p>
      We deliver delicious meals from multiple cuisines — Gujarati, Punjabi, Chinese, Pizzas, Desserts,
      and more. Our mission is to serve food that not only fills your stomach but also your heart with joy.
    </p>
  </section>

  <!-- CATEGORIES SECTION -->
  <section id="home-categories" class="categories-section">
    <h2>Popular Categories</h2>
    <div class="category-grid">
      <div class="category-card">
        <img src="Images/Pizzaes.jpg" alt="Pizza">
        <h3>Pizza</h3>
      </div>
      <div class="category-card">
        <img src="Images/Gujrati-food.jpg" alt="Gujarati Food">
        <h3>Gujarati</h3>
      </div>
      <div class="category-card">
        <img src="Images/Chinese-food.jpg" alt="Chinese Food">
        <h3>Chinese</h3>
      </div>
      <div class="category-card">
        <img src="Images/desserts.jpg" alt="Desserts">
        <h3>Desserts</h3>
      </div>
      <div class="category-card">
        <img src="Images/drinks.jpg" alt="Drinks">
        <h3>Drinks</h3>
      </div>
    </div>
    <a href="Category.php" class="explore-btn">Explore More</a>
  </section>

  <!-- CTA SECTION -->
  <section id="home-cta" class="cta-section">
    <h2>Hungry Already?</h2>
    <a href="Category.php">Order Now</a>
  </section>

  <?php include 'Footer.php'; ?>

</body>

</html>